using Microsoft.VisualStudio.TestTools.UnitTesting;
using SonarCloud.Controllers;

namespace SonarCloudTests
{
    [TestClass]
    public class ValuesControllerTests
    {
        [TestMethod]
        public void TestMethod1()
        {
            ValuesController controller = new ValuesController();
        }
    }
}
